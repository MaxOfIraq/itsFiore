//
//  Button2.swift
//  HixColor
//
//  Created by Ahmed Salah on 2/15/19.
//  Copyright © 2019 Ahmed Salah. All rights reserved.
//

import AVKit
class Button2 : UIButton{
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 10
        
        
    }
    
}
