//
//  MessegeBox.swift
//  HixColor
//
//  Created by Ahmed Salah on 2/14/19.
//  Copyright © 2019 Ahmed Salah. All rights reserved.
//

import UIKit

class MessegeBox: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func exit(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
    }
    

    @IBAction func twitter(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://twitter.com/its_Fywre")! as URL, options : [:],completionHandler: nil)
    }
    
    
    @IBAction func paypal(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://www.paypal.me/AhmedSalahStore")! as URL, options : [:],completionHandler: nil)
    }
    
    
    
    
    
}
