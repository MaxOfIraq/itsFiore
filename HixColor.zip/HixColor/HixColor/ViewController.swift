//
//  ViewController.swift
//  HixColor
//
//  Created by Ahmed Salah on 2/14/19.
//  Copyright © 2019 Ahmed Salah. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController , UIWebViewDelegate{

    @IBOutlet weak var website: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        website.delegate = self
        let url = URL(string: "https://ifenix.me/HixColor/")
        website.loadRequest(URLRequest(url: url!))

    }
    @IBAction func reload(_ sender: Any)
    {
        website.reload()
    }
    
    @IBOutlet weak var Activ: UIActivityIndicatorView!
    
    
    func webViewDidStartLoad(_ webView: UIWebView)
    {
        Activ.startAnimating()
    }
    
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        Activ.stopAnimating()
    }

    
    
    
    
}

